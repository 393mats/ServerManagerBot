<?php 

namespace svmPlugin;
use pocketmine\plugin\PluginBase;

class svmPlugin extends PluginBase {
	public function onEnable(){
		$this->getLogger()->info("Server Manager is enabled");
    }
    
    public function onJoin(PlayerJoinEvent $e){
        $pl = $e->getPlayer();
        $pl->sendMessage("Hello World");
    }
}